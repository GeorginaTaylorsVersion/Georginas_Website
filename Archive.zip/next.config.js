module.exports = {
  output: 'export',
  images: {
    unoptimized: true
  }
}; 